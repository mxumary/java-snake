import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;

/** 
 *  You can use this file (and others) to test your
 *  implementation.
 */

public class GameTest {
    
    public static final int BOARD_WIDTH = 650;
    public static final int BOARD_HEIGHT = 600;
    SpeedTreat spt = new SpeedTreat(BOARD_WIDTH, BOARD_HEIGHT, Color.ORANGE);
    SnakeChunk s = new SnakeChunk(BOARD_WIDTH, BOARD_HEIGHT, Color.GREEN);
    GrowTreat t = new GrowTreat(BOARD_WIDTH, BOARD_HEIGHT, Color.RED);
    
    @Test
    public void speedUpWithTreat() { // how to test with interval?
        spt.effect(s);
        assertEquals(110, Logic.getInterval());
    }
    
    @Test
    public void growWithTreat() {
        t.effect(s);
        assertEquals(2, s.getBody().size());
    }
    @Test
    public void snakeMovesDown() {
        Point p = s.getBody().peekFirst();
        p.setX(0);
        p.setY(0);
        s.setVy(1);
        s.move();
        assertEquals(0, p.getX());
        assertEquals(20, p.getY());
    }
    
    @Test
    public void snakeMovesUp() {
        Point p = s.getBody().peekFirst();
        p.setX(50);
        p.setY(50);
        s.setVy(-1);
        s.move();
        assertEquals(50, p.getX());
        assertEquals(30, p.getY());
    }
    
    @Test
    public void snakeMovesRight() {
        Point p = s.getBody().peekFirst();
        p.setX(50);
        p.setY(50);
        s.setVx(1);
        s.move();
        assertEquals(70, p.getX());
        assertEquals(50, p.getY());
    }
    
    @Test
    public void snakeMovesLeft() {
        Point p = s.getBody().peekFirst();
        p.setX(50);
        p.setY(50);
        s.setVx(-1);
        s.move();
        assertEquals(30, p.getX());
        assertEquals(50, p.getY());
    }
    
    @Test
    public void snakeGrows() {
        s.grow();
        s.grow();
        s.grow();
        assertEquals(4, s.getBody().size());
    }
    @Test
    public void snakeSelfCollision() {
        for (int i = 0; i < 5; i++) {
            s.grow();
        }
        assertEquals(6, s.getBody().size());
        s.setVx(1);
        s.move(); // move right
        s.setVx(0);
        s.setVy(1);
        s.move(); // move down
        s.setVx(-1);
        s.setVy(0);
        s.move(); // move to the left
        s.setVy(-1);
        s.setVx(0);
        s.move(); // move up
        assertTrue(s.selfCollision(), "snake has collided with itself"); // self collision
    }
    
    @Test
    public void snakeWallHitRight() { // size of snake: 20, board width: 650
        s.setVx(1);
        for (int i = 0; i < 33; i++) {
            s.move();
        }
        assertTrue(s.hitWall());
    }
    
    @Test
    public void snakeWallHitBottom() { // size of snake: 20, board height: 600
        s.setVy(1);
        for (int i = 0; i < 30; i++) {
            s.move();
        }
        assertTrue(s.hitWall());
    }
    
    @Test
    public void snakeWallHitTop() {
        s.setVy(-1);
        for (int i = 0; i < 30; i++) {
            s.move();
        }
        assertTrue(s.hitWall());
    }
    
    @Test
    public void snakeWallHitLeft() {
        s.setVx(1);
        for (int i = 0; i < 33; i++) {
            s.move();
        }
        assertTrue(s.hitWall());
    }
    
    @Test
    public void snakeIntersectsTreat() {
        s.setPx(10);
        s.setPy(10);
        System.out.println("px: " + s.getPx());
        System.out.println("py: " + s.getPy());
        t.setPx(30);
        t.setPy(10);
        s.setVx(1);
        s.move();
        System.out.println("px: " + s.getPx());
        System.out.println("py: " + s.getPy());
        assertTrue(s.intersects(t));
    }
}
