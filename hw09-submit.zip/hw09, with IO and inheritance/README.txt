=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: mxumary
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an appropriate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. Collections. THIS IS DIFFERENT FROM MY PROPOSAL, and I emailed my TAs to update them on this.
  Rather than using a 2D array for the board and snake, I used a LinkedList to hold the snake. This
  is better than a 2D array because you can easily insert elements, which is precisely what
  I needed to move the snake (for my implementation).

  2. File I/O. THIS IS ALSO DIFFERENT FROM MY PROPOSAL. In my original proposal, I stated that I
  wanted to use File I/O to store the game state, but I realized that this is not appropriate
  since Snake is reliant on a timer. From the user experience perspective, where you cannot "stop"
  the snake, "saving" the game is a little unrealistic.
  I changed File I/O to store high scores: a username and the score (we get the score from the 
  length of the snake).

  3. Dynamic Dispatch. The classes Snake and Treat extend GameObj. In particular, SpeedTreat and 
  GrowTreat extend the Treat class and implement the method effect() differently. SpeedTreat
  changes the interval at which the timer ticks, which makes the snake go faster and GrowTreat
  grows the snake. This is best because I needed the treat to affect the snake differently, 
  and if I wanted to make a different treat, implementation would be a little more convenient.

  4. Testable component. This is kept the same from my proposal, but I test how the snake moves,
  how it is affected when it eats a treat, when it runs into itself, and when it runs into a wall.
  This is important because the core game state should stay separate from the GUI.

=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.
Game: Game contains the layout of my game and the main method to start and run the game. 
It initializes the GUI elements specified in Game and runs it.
GameObj: This is from the Mushroom of Doom code, but this contains several variables and methods
that would apply to my snake and treats. The most specific 
GrowTreat: extends treat and implements effect(), such that when a snake eats a GrowTreat, it 
grows by one.
Logic: this contains most of my game logic, including the process of sorting high scores when the 
game is over, conditions for ending the game, how key presses affect snake movement, and 
conditions for when a snake eats a treat.
Point: my snake is made up of a LinkedList of points, so I had to implement this primarily for
getting and setting the x and y coordinate.
SnakeChunk: this is the snake body and contains code on how the snake moves, grows, and runs into
itself.
SpeedTreat: this extends Treat and implements effect(), such that when a snake eats a SpeedTreat,
the interval of the timer decreases by 10 (thus making the snake go "faster").
Treat: this is an abstract class that extends GameObj. It contains most of the guidelines on how a 
Treat should behave, especially with how it randomly spawns onto the board.
UserScore:

- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?
Starting to actually implement classes and figure out how it all relates to each other while making
sure that I was still following my proposal was difficult.

However, I think looking at the Javadocs and the Piazza posts helped me, along with looking at the example
code provided (particularly Mushroom of Doom).

- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance?
I think that when it comes to separating the functionality of the treats and the snake, most of the
methods (like the snake moving or growing or the treat's effect on the treat) is in its proper
classes. I can see how moving the hitWall method to the Snake specifically would be a better idea,
but I also think that keeping it in the GameObj for future modifications (eg if we had a new class
that extended GameObj that wanted to bounce off of the walls) would make changing my code more
convenient. 

I think my private state is encapsulated well because my private variables have getters and setters.


========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.
  https://www.educative.io/edpresso/how-to-generate-random-numbers-in-java
